﻿using Microsoft.AspNetCore.Mvc;
using MVCDBProject.Models;
using System.Linq;

namespace MVCDBProject.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly MVCDbContext _context;

        public EmployeeController(MVCDbContext context)
        {
            _context = context;
        }

        // 1. Index: Display all employees
        public IActionResult Index()
        {
            var employees = _context.Employees.ToList();
            return View(employees);
        }

        // 2. Create: GET method to show the create form
        public IActionResult Create()
        {
            return View();
        }

        // 3. Create: POST method to add a new employee
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                _context.Employees.Add(employee);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        // 4. Edit: GET method to display the edit form
        public IActionResult Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var employee = _context.Employees.Find(id);
            if (employee == null)
                return NotFound();

            return View(employee);
        }

        // 5. Edit: POST method to update the employee details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Employee employee)
        {
            if (id != employee.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(employee);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        // 6. Delete: GET method to confirm deletion
        public IActionResult Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var employee = _context.Employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
                return NotFound();

            return View(employee);
        }

        // 7. Delete: POST method to delete the employee
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
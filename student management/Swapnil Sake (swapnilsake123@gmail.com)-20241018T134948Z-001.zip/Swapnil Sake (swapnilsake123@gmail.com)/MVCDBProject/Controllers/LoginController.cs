﻿using Microsoft.AspNetCore.Mvc;
using MVCDBProject.Models;

namespace MVCDBProject.Controllers
{
    public class LoginController : Controller
    {
        private readonly MVCDbContext _context;

        public LoginController(MVCDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (user != null)
            {
                return RedirectToAction("Index", "Employee");
            }
            ModelState.AddModelError("", "Invalid login attempt.");
            return View();
        }

        [HttpGet]
        public IActionResult Signup()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Signup(User user)
        {
            // Check if the email already exists
            var existingUser = _context.Users.FirstOrDefault(u => u.Email == user.Email);
            if (existingUser != null)
            {
                // If email exists, show an error
                ModelState.AddModelError("Email", "Email already exists.");
            }

            // Check if the username already exists
            //var existingUsername = _context.Users.FirstOrDefault(u => u.Password == user.Password);
            //if (existingUsername != null)
            //{
                // If username exists, show an error
                //ModelState.AddModelError("Name", "Username already exists.");
            //}

            if (ModelState.IsValid)
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                return RedirectToAction("Login");
            }
            return View(user);

        }


        public IActionResult Index()
        {
            return View();
        }
    }
}

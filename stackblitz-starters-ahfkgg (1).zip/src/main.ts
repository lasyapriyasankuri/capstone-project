import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, RouterOutlet, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { JobListComponent } from './app/components/job-list/job-list.component';
import { JobDetailComponent } from './app/components/job-detail/job-detail.component';
import { UserProfileComponent } from './app/components/user-profile/user-profile.component';
import { SkillAssessmentComponent } from './app/components/skill-assessment/skill-assessment.component';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, HttpClientModule],
  template: `
    <div class="container">
      <header>
        <h1>Online Job Portal</h1>
        <nav>
          <a routerLink="/jobs" routerLinkActive="active">Jobs</a>
          <a routerLink="/profile" routerLinkActive="active">Profile</a>
          <a routerLink="/assessment" routerLinkActive="active">Skill Assessment</a>
        </nav>
      </header>
      <main>
        <router-outlet></router-outlet>
      </main>
      <footer>
        <p>&copy; 2023 Online Job Portal. All rights reserved.</p>
      </footer>
    </div>
  `,
  styles: [`
    .container {
      font-family: Arial, sans-serif;
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }
    header {
      background-color: #1976d2;
      color: white;
      padding: 20px;
      border-radius: 8px 8px 0 0;
    }
    h1 {
      margin: 0;
      font-size: 24px;
    }
    nav {
      margin-top: 20px;
    }
    nav a {
      color: white;
      text-decoration: none;
      margin-right: 20px;
      font-size: 18px;
      transition: color 0.3s;
    }
    nav a:hover, nav a.active {
      color: #ffeb3b;
    }
    main {
      background-color: white;
      padding: 20px;
      border-radius: 0 0 8px 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    footer {
      text-align: center;
      margin-top: 20px;
      color: #666;
    }
  `]
})
export class App {}

bootstrapApplication(App, {
  providers: [
    provideRouter([
      { path: '', redirectTo: '/jobs', pathMatch: 'full' },
      { path: 'jobs', component: JobListComponent },
      { path: 'jobs/:id', component: JobDetailComponent },
      { path: 'profile', component: UserProfileComponent },
      { path: 'assessment', component: SkillAssessmentComponent }
    ])
  ]
}).catch(err => console.error(err));
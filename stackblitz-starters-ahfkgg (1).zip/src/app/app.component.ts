import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <nav>
      <a routerLink="/jobs">Jobs</a> |
      <a routerLink="/profile">Profile</a> |
      <a routerLink="/assessment">Skill Assessment</a>
    </nav>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'Online Job Portal';
}
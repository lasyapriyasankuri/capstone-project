import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { JobListComponent } from './components/job-list/job-list.component';
import { JobDetailComponent } from './components/job-detail/job-detail.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { SkillAssessmentComponent } from './components/skill-assessment/skill-assessment.component';
import { JobService } from './services/job.service';
import { UserService } from './services/user.service';

@NgModule({
  declarations: [
    AppComponent,
    JobListComponent,
    JobDetailComponent,
    UserProfileComponent,
    SkillAssessmentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', redirectTo: '/jobs', pathMatch: 'full' },
      { path: 'jobs', component: JobListComponent },
      { path: 'jobs/:id', component: JobDetailComponent },
      { path: 'profile', component: UserProfileComponent },
      { path: 'assessment', component: SkillAssessmentComponent }
    ])
  ],
  providers: [JobService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }